const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../scripts/tag_script/engine.js');

const makePost = (tags, extra = {}) => E.postDataFromApi({
  id: 1, tag_string: tags, rating: 's', score: { total: 10 },
  file: { ext: 'png', width: 100, height: 200, size: 1000 },
  relationships: {}, ...extra
});

test('simple mode: conditional add and plain tags', () => {
  assert.equal(E.runTagScript(makePost('cat'), '[if cat, feline] dog', false), 'feline dog');
});

test('simple mode: negated condition', () => {
  assert.equal(E.runTagScript(makePost('cat'), '[if -dog, no_dog]', false), 'no_dog');
});

test('[reset] removes all current tags', () => {
  assert.equal(E.runTagScript(makePost('a b'), '[reset] new_tag', false), '-a -b new_tag');
});

test('extended: OR predicate', () => {
  assert.equal(E.runTagScript(makePost('wolf'), '[if ~dog ~wolf, canine]', true), 'canine');
  assert.equal(E.runTagScript(makePost('cat'), '[if ~dog ~wolf, canine]', true), '');
});

test('extended: wildcard', () => {
  assert.equal(E.runTagScript(makePost('red_dragon'), '[if *dragon*, mythical]', true), 'mythical');
});

test('extended: nested [reset]', () => {
  assert.equal(E.runTagScript(makePost('cat dog'), '[if cat, [reset] lion]', true), '-cat -dog lion');
});

test('extended: numeric metatag', () => {
  assert.equal(E.runTagScript(makePost('x', { score: { total: 10 } }), '[if score:>=5, popular]', true), 'popular');
  assert.equal(E.runTagScript(makePost('x', { score: { total: 1 } }), '[if score:>=5, popular]', true), '');
});

test('extended: unsupported metatag throws instead of silently mismatching', () => {
  assert.throws(() => E.runTagScript(makePost('x'), '[if voted:up, y]', true), E.UnsupportedTermError);
});

test('postDataFromApi accepts tags grouped by category', () => {
  const p = E.postDataFromApi({ id: 2, tags: { general: ['a'], species: ['b'] }, file: {}, relationships: {} });
  assert.deepEqual([...p.tagsSet], ['a', 'b']);
});